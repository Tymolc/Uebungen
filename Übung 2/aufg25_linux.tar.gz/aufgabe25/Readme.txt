Betriebssysteme I WS 2012/2013

Uebung 2

Um das erzeugte Programm ausfuehren zu koennen, muss zuvor eine Umgebungsvariable 
fuer den Bibliothekssuchpfad (LD_LIBRARY_PATH) gesetzt werden. Das geschieht mit 
Hilfe der Datei setenv, welche durch den Aufruf:

source setenv

die Variable setzt.

Es wird nur die Architektur (uname -m) x86_64 auf dem InstantLab Referenzsystem unterstuetzt.
